package com.example.courtball;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView  scoreA,scoreB;


    Button threeA,twoA,oneA,threeB,twoB,oneB;
    int score=0;
    int s2=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scoreA=findViewById(R.id.scoreA);
        threeA=findViewById(R.id.three_A);
        twoA=findViewById(R.id.two_A);
        oneA=findViewById(R.id.free_A);


        scoreB=findViewById(R.id.scoreB);
        threeB=findViewById(R.id.three_B);
        twoB=findViewById(R.id.two_B);
        oneB=findViewById(R.id.free_B);



    }

    public void threePointsA(View view) {
        score=score+3;
        DisplayPoints(score);
    }

    public void twoPointsA(View view) {

        score=score+2;
        DisplayPoints(score);
    }

    public void OnePointsA(View view) {
        score=score+1;
        DisplayPoints(score);
    }


    public void DisplayPoints(int display)
    {
        scoreA.setText(String.valueOf(display));

    }

    public void threePointsB(View view) {

        s2=s2+3;
        Display2(s2);

    }

    public void twoPointsB(View view) {

        s2=s2+2;
        Display2(s2);
    }

    public void OnePointsB(View view) {
        s2=s2+1;
        Display2(s2);

    }

    public  void Display2(int a)
    {
        scoreB.setText(String.valueOf(a));
    }

    public void ResetVlaue(View view) {

        score=0;
        s2=0;

        scoreA.setText(String.valueOf(score));
        scoreB.setText(String.valueOf(s2));

    }
}
